# InteractionVisualizer Languages

https://www.spigotmc.org/resources/77050/

https://github.com/LOOHP/InteractionVisualizer

***
### Configurations in different Languages contributed by different people in the community!

**Some translations might be inaccurate or not up to date**, but the default English language is always up to date.

Even if the config is outdated, you can still reference it and in most cases, you can still apply it as the plugin will generate the missing options.

***

**You are always welcome to contribute to this list!**

**Huge thanks** to everyone who contributed!

## Languages available:
- English (default)
- Spanish (by Itaquito)
- French (by Cry_Legende)
- Brazilian Portuguese (by fabricio9898)
- Russian (by imDaniX)
- Simplified Chinese (by StarYunmeng, BackWheel, EsummerConnor & ahdg6)
- Persian (by tntbaz)
- German (by Nachtalb)
- Italian (by MrBackSlash-it)
- Swedish (by Luracasmus)
- Turkish (by Over_Brave)
- Korean (by dd397)
- Japanese (by ringo360)
